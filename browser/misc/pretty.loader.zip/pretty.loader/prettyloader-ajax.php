<?php
$i = 0;
while ($i <= 10000000) {
	# code...
	$i++;
};
?>
UPDATED!!!<br />
This content had been loaded in Ajax.